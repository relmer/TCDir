Sample archive for TCDir manual testing.
